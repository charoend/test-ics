import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';
import 'modules/dashboard/bloc/place_bloc.dart';
import 'modules/dashboard/screens/pages/homes/home_page.dart';

// ***************************************************************************************** //
// ********** Section 0 | Get Current User  ********* //
// ***************************************************************************************** //
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    MyApp(),
  );
}
// ***************************************************************************************** //
// ********** Section 0 | Get Current User  ********* //
// ***************************************************************************************** //

// ***************************************************************************************** //
// ********** Section 1 | Run App  ********* //
// ***************************************************************************************** //
class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ----- Setup MultiProvider ----- //
    return MultiProvider(
      providers: _multiProvider,
      child: const MyAppHome(),
    );
    // ----- Setup MultiProvider ----- //
  }

  // ----- Provider Get Data ----- //
  final List<SingleChildWidget> _multiProvider = [
    ChangeNotifierProvider<PlaceBloc>(
      create: (context) => PlaceBloc(),
    ),
  ];
  // ----- Provider Get Data ----- //
}

class MyAppHome extends StatelessWidget {
  const MyAppHome({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(fontFamily: 'Kanit'),
      
      // ----- j ----- //
      home: FirebaseAuth.instance.currentUser == null
          ? const HomePage() //SplashLoginScreen()
          : const HomePage(), //Appp(), // NavigationBarHome(),  // LauncherPages(),
      // ----- j ----- //
    );
  }
}

// ***************************************************************************************** //
// ********** Section 1 | Run App  ********* //
// ***************************************************************************************** //
