class PlaceModel {
  //data Type
  int? id;
  String? name;
  List? categories;
  String? profileImageUrl;
  List? images;
  List? operationTime;
  String? address;
  double? rating;

  PlaceModel({
    this.id,
    this.name,
    this.categories,
    this.profileImageUrl,
    this.images,
    this.operationTime,
    this.address,
    this.rating,
  });

  PlaceModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    categories = json['categories'];
    profileImageUrl = json['profile_image_url'];
    images = json['images'];
    operationTime = json['operation_time'];
    address = json['address'];
    rating = json['rating'];
  }
}
