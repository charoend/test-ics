import 'package:flutter/material.dart';
import 'package:ics/modules/dashboard/bloc/place_bloc.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    getPlaceData();
  }

  Future getPlaceData() async {
    await context.read<PlaceBloc>().getPlaceData();
  }

  @override
  Widget build(BuildContext context) {
    final pb = context.watch<PlaceBloc>();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF134B8A),
        title: Padding(
          padding: EdgeInsets.only(
            top: 5.0,
            bottom: 10.0,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: Image.asset(
              'assets/logo/icon/ico_default_512.png',
              fit: BoxFit.contain,
              width: 50.0,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(
              top: 5.0,
              bottom: 10.0,
              right: 5.0,
            ),
            child: ClipRRect(
                borderRadius: BorderRadius.circular(100.0),
                child: CircleAvatar(
                  radius: 30.0,
                )
                //  Image.asset(
                //   'assets/logo/icon/ico_default_512.png',
                //   fit: BoxFit.contain,
                //   width: 50.0,
                // ),
                ),
          ),
        ],
      ),
      body: ListView.builder(
        shrinkWrap: true,
        itemCount: pb.placeData.length,
        itemBuilder: (context, index) {
          // pb.placeData[index].name
          return Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: ListTile(
                    title: Text('${pb.placeData[index].name}'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_month),
                      Text(
                          '${pb.placeData[index].operationTime![0]['time_open']}  ${pb.placeData[index].operationTime![0]['time_close']} '),
                      Text('${pb.placeData[index].rating}')
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(5.0),
                  child: Image.network(
                    '${pb.placeData[index].profileImageUrl}',
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }
}

