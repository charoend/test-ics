import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:ics/modules/dashboard/models/place_model.dart';

class PlaceBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<PlaceModel> _placeData = [];
  List<PlaceModel> get placeData => _placeData;

  bool _isLoading = true;
  bool get loading => _isLoading;

  Future getPlaceData() async {
    _placeData.clear();
    //read json file
    final jsondata =
        await rootBundle.loadString('assets/files/example_data.json');
    //decode json data as list
    final list = json.decode(jsondata) as List<dynamic>;
    //map json and initialize using DataModel
    _placeData = list.map((e) => PlaceModel.fromJson(e)).toList();
    _isLoading = false;
    notifyListeners();
  }

  onRefresh(mounted) {
    _isLoading = true;
    _placeData.clear();
    getPlaceData();
    notifyListeners();
  }
}
