package com.test.ass.ics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
